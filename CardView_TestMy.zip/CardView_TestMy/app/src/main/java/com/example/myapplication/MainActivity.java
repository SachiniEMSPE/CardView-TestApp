package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private CardView schoolCardView, restaurantCardView, hospitalCardView,libraryCardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        schoolCardView = findViewById(R.id.schoolCardViewID);
        libraryCardView = findViewById(R.id.libraryCardViewID);
        restaurantCardView = findViewById(R.id.restaurantCardViewID);
        hospitalCardView = findViewById(R.id.hospitalCardViewID);

        schoolCardView.setOnClickListener(this);
        libraryCardView.setOnClickListener(this);
        restaurantCardView.setOnClickListener(this);
        hospitalCardView.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.schoolCardViewID:
            {

               intent = new Intent(this,schoolActivity.class);
               startActivity( intent);
               break;
            }
            case R.id.libraryCardViewID:
            {

                intent = new Intent(this,LibraryActivity.class);
                startActivity( intent);
                break;
            }
            case R.id.restaurantCardViewID:
            {

                intent = new Intent(this,RestaurantActivity.class);
                startActivity( intent);
                break;
            }
            case R.id.hospitalCardViewID:
            {

                intent = new Intent(this,HospitalActivity.class);
                startActivity( intent);
                break;
            }
        }

    }
}
